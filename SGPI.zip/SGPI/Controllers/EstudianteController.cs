﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SGPI.Models;

namespace SGPI.Controllers
{
    public class EstudianteController : Controller
    {

        SGPIDBContext context = new SGPIDBContext();

        public IActionResult Actualizar(int? IdUsuario)
        {
            Usuario usuario = context.Usuarios.Find(IdUsuario);

            if (usuario != null)
            {
                ViewBag.documento = context.Documentos.ToList();
                ViewBag.genero = context.Generos.ToList();
                ViewBag.programa = context.Programas.ToList();
                return View(usuario);
            }
            else
            {
                return Redirect("/Administrador/Login");
            }

           
        }
        [HttpPost]

        public IActionResult Actualizar(Usuario usuario)
        {
            var usuarioActualizar = context.Usuarios.Where(consulta => consulta.IdUsuario == usuario.IdUsuario).FirstOrDefault();

            //Usuario usuarioActualizar = context.Usuarios.Find(usuario);
            usuarioActualizar.NumeroDocumento = usuario.NumeroDocumento;
            usuarioActualizar.PrimerNombre = usuario.PrimerNombre;
            usuarioActualizar.SegundoNombre = usuario.SegundoNombre;
            usuarioActualizar.PrimerApellido = usuario.PrimerApellido;
            usuarioActualizar.SegundoApellido = usuario.SegundoApellido;
            usuarioActualizar.IdPrograma = usuario.IdPrograma;
            usuarioActualizar.IdGenero = usuario.IdGenero;
            usuarioActualizar.Password = usuario.Password;

            context.Update(usuarioActualizar);
            context.SaveChanges();

            return Redirect("Estudiante/Actualizar/?IdUsuario=" + usuarioActualizar.IdUsuario);
        }

        public IActionResult Pagos(int? IdUsuario) 
        {
            Usuario usuario = new Usuario();
            var usr = context.Usuarios.Where(consulta => consulta.IdUsuario == IdUsuario).FirstOrDefault();
            ViewBag.idusuario = usr.IdUsuario;
            return View();
        }
        
        [HttpPost]
        public IActionResult Pagos(Pago pago, Estudiante estudiante)            
        {

            var pagoActualizar = context.Estudiantes
                .Where(consulta => consulta.IdUsuario == estudiante.IdUsuario).FirstOrDefault();

            pago.Estado = true;
            context.Pagos.Add(pago);           
            context.SaveChanges();
            ViewBag.mensaje = "Pago exitoso";

            pagoActualizar.IdPago = pago.IdPago;
            pagoActualizar.IdUsuario = estudiante.IdUsuario;
            pagoActualizar.Archivo = "";
            pagoActualizar.Egreado = true;

            context.Update(pagoActualizar);
            context.SaveChanges();

                      
           return View();
        }
    }
}
